  let output = 0;
const screen = document.getElementById("screen");

function updateScreen() {
  screen.textContent = output;
}

// Increment
document.getElementById("plus-btn").addEventListener("click", function() {
  output++;
  updateScreen();
});

// Decrement
document.getElementById("minus-btn").addEventListener("click", function() {
  output--;
  updateScreen();
});

// Reset
document.getElementById("reset-btn").addEventListener("click", function() {
  output = 0;
  updateScreen();
});